// Persona Assistant — Backend
// Handles chat requests from the mobile app and talks to the Anthropic API.
// The API key NEVER lives in the mobile app — only here, on the server.

const express = require('express');
const cors = require('cors');
require('dotenv').config();
const { initDB } = require('./db');
const store = require('./models/store');

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6';

if (!ANTHROPIC_API_KEY) {
  console.warn('⚠️  ANTHROPIC_API_KEY is not set. Add it to backend/.env');
}

// ---- Routes ----

app.get('/health', (req, res) => res.json({ ok: true }));

app.get('/api/persona/:userId', async (req, res) => {
  const user = await store.getOrCreateUser(req.params.userId);
  res.json(user.persona);
});

app.post('/api/persona/:userId', async (req, res) => {
  const persona = await store.updatePersona(req.params.userId, req.body);
  res.json(persona);
});

app.post('/api/chat/:userId', async (req, res) => {
  const { message } = req.body;
  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'message is required' });
  }

  const userId = req.params.userId;
  const user = await store.getOrCreateUser(userId);
  await store.addMessage(userId, 'user', message);

  const recentMessages = await store.getRecentMessages(userId, 30);

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 800,
        system: user.persona.systemPrompt,
        messages: recentMessages,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('Anthropic API error:', errText);
      return res.status(502).json({ error: 'AI service error' });
    }

    const data = await response.json();
    const replyText = data.content
      .filter((b) => b.type === 'text')
      .map((b) => b.text)
      .join('\n');

    await store.addMessage(userId, 'assistant', replyText);

    res.json({ reply: replyText });
  } catch (err) {
    console.error('Chat error:', err);
    res.status(500).json({ error: 'internal error' });
  }
});

app.delete('/api/chat/:userId', async (req, res) => {
  await store.clearMessages(req.params.userId);
  res.json({ ok: true });
});

const PORT = process.env.PORT || 3000;

initDB()
  .then(() => {
    app.listen(PORT, () => console.log(`Persona backend running on port ${PORT}`));
  })
  .catch((err) => {
    console.error('❌ Failed to connect to Neon/Postgres:', err.message);
    process.exit(1);
  });
