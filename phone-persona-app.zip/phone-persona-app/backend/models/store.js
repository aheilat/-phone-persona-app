const { pool } = require('../db');

const DEFAULT_PERSONA = {
  name: 'رفيق',
  language: 'ar',
  tone: 'دافئ، مباشر، ذكي، فيه روح خفيفة بدون مبالغة',
  systemPrompt: `أنت "رفيق" — مساعد شخصي بشخصية مميزة يعيش داخل تطبيق جوال.
تتكلم بالعربية الفصحى المبسطة الممزوجة بلمسة خليجية خفيفة عند المناسبة.
أسلوبك: مباشر، دافئ، عملي — تساعد المستخدم في مهامه اليومية (تذكيرات، تنظيم، أسئلة، محادثة).
لا تتصرف كروبوت جامد؛ عندك شخصية ثابتة يتذكرها المستخدم بين المحادثات.
اجعل ردودك مختصرة ومناسبة لشاشة الجوال ما لم يطلب المستخدم تفصيلاً أكثر.`,
};

async function getOrCreateUser(userId) {
  let { rows } = await pool.query('SELECT * FROM users WHERE user_id = $1', [userId]);
  if (rows.length === 0) {
    await pool.query('INSERT INTO users (user_id, persona) VALUES ($1, $2)', [
      userId,
      DEFAULT_PERSONA,
    ]);
    ({ rows } = await pool.query('SELECT * FROM users WHERE user_id = $1', [userId]));
  }
  return rows[0];
}

async function updatePersona(userId, updates) {
  const user = await getOrCreateUser(userId);
  const merged = { ...user.persona, ...updates };
  await pool.query('UPDATE users SET persona = $1 WHERE user_id = $2', [merged, userId]);
  return merged;
}

async function getRecentMessages(userId, limit = 30) {
  const { rows } = await pool.query(
    `SELECT role, content FROM messages
     WHERE user_id = $1
     ORDER BY created_at ASC
     OFFSET GREATEST((SELECT COUNT(*) FROM messages WHERE user_id = $1) - $2, 0)`,
    [userId, limit]
  );
  return rows;
}

async function addMessage(userId, role, content) {
  await pool.query('INSERT INTO messages (user_id, role, content) VALUES ($1, $2, $3)', [
    userId,
    role,
    content,
  ]);
}

async function clearMessages(userId) {
  await pool.query('DELETE FROM messages WHERE user_id = $1', [userId]);
}

module.exports = {
  getOrCreateUser,
  updatePersona,
  getRecentMessages,
  addMessage,
  clearMessages,
};
