import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function OnboardingScreen({ onStart }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>تعرف على رفيق 👋</Text>
      <Text style={styles.subtitle}>
        مساعدك الشخصي بشخصية حقيقية — يتذكرك، يساعدك في يومك، ويتكلم لغتك.
      </Text>
      <TouchableOpacity style={styles.button} onPress={onStart}>
        <Text style={styles.buttonText}>ابدأ المحادثة</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24, backgroundColor: '#1E1B2E' },
  title: { fontSize: 26, fontWeight: '800', color: '#fff', marginBottom: 12, textAlign: 'center' },
  subtitle: { fontSize: 16, color: '#ccc', textAlign: 'center', marginBottom: 32, lineHeight: 24 },
  button: { backgroundColor: '#6C5CE7', paddingVertical: 14, paddingHorizontal: 32, borderRadius: 24 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
