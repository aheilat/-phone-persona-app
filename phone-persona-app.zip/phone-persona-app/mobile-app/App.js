import React, { useState, useEffect } from 'react';
import { I18nManager, StatusBar } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ChatScreen from './screens/ChatScreen';
import OnboardingScreen from './screens/OnboardingScreen';

// Force RTL layout — this app is Arabic-first
I18nManager.allowRTL(true);
I18nManager.forceRTL(true);

export default function App() {
  const [userId, setUserId] = useState(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    (async () => {
      let id = await AsyncStorage.getItem('userId');
      if (!id) {
        id = 'user_' + Math.random().toString(36).slice(2, 12);
        await AsyncStorage.setItem('userId', id);
      }
      setUserId(id);
      setReady(true);
    })();
  }, []);

  if (!ready) return null;

  return (
    <>
      <StatusBar barStyle="dark-content" />
      <ChatScreen userId={userId} />
    </>
  );
}
