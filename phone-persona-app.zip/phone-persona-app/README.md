# رفيق — Persona Assistant

مساعد شخصي بشخصية ثابتة، يعيش داخل تطبيق جوال (iOS + Android)، ويتكلم مع المستخدم عبر Claude API.

## البنية

```
phone-persona-app/
├── backend/          # سيرفر Node.js/Express — يحمي مفتاح API ويدير الشخصية والذاكرة
└── mobile-app/        # تطبيق React Native (Expo) — الواجهة اللي يستخدمها المستخدم
```

## 1. تشغيل الـ Backend محليًا

```bash
cd backend
npm install
cp .env.example .env
```

افتح `.env` وحط:
- `ANTHROPIC_API_KEY` — مفتاح Anthropic الخاص بك
- `DATABASE_URL` — رابط الاتصال من Neon (خطوات تحته)

```bash
npm run dev
```
يشتغل على `http://localhost:3000`. عند أول تشغيل، السيرفر ينشئ جداول قاعدة البيانات (`users`, `messages`) تلقائيًا.

### تجهيز قاعدة بيانات Neon (Postgres)

1. روح [console.neon.tech](https://console.neon.tech) وسجل دخول (أو أنشئ حساب مجاني — ما يحتاج بطاقة ائتمان)
2. اضغط **Create a project**، اختر اسم واختر منطقة قريبة
3. بعد إنشاء المشروع، من صفحة **Connection Details** انسخ **Connection string** — يشبه:
   ```
   postgresql://username:password@ep-xxxxx.region.aws.neon.tech/dbname?sslmode=require
   ```
4. حط الرابط كامل في `DATABASE_URL` داخل `.env`

كل مستخدم يتخزن كصف في جدول `users` (يحمل الشخصية كـ JSON)، وكل رسالة تتخزن كصف في جدول `messages` مرتبط به.

## 2. تشغيل التطبيق محليًا

```bash
cd mobile-app
npm install
```

افتح `screens/ChatScreen.js` وغيّر:
```js
const API_BASE_URL = 'https://YOUR-BACKEND-URL.com';
```
لأثناء التطوير المحلي على جهاز حقيقي، استخدم IP جهازك بدل localhost (مثال: `http://192.168.1.5:3000`).

```bash
npx expo start
```
امسح الـ QR code بتطبيق **Expo Go** على جوالك للتجربة الفورية.

## 3. نشر الـ Backend (قبل النشر على المتاجر)

انشر مجلد `backend/` على أي منصة (Render، Railway، Fly.io، DigitalOcean...) وتأكد من:
- ضبط `ANTHROPIC_API_KEY` كمتغير بيئة سري (مو داخل الكود)
- استبدال التخزين المؤقت في الذاكرة (`users = {}`) بقاعدة بيانات حقيقية (Postgres/MongoDB) — التخزين الحالي يُمسح عند إعادة تشغيل السيرفر

## 4. النشر على Google Play وApp Store

هذا الجزء تسويه أنت (يحتاج حسابات مطورين باسمك):

**الأدوات المطلوبة:**
```bash
npm install -g eas-cli
eas login
```

**بناء التطبيق:**
```bash
cd mobile-app
eas build --platform android   # لإنتاج ملف .aab لـ Google Play
eas build --platform ios       # لإنتاج ملف لـ App Store
```

**الحسابات المطلوبة:**
- حساب Google Play Developer (رسوم تسجيل لمرة واحدة)
- حساب Apple Developer (رسوم سنوية)

**قبل الرفع، لازم تجهز:**
- أيقونة التطبيق وصور splash screen (حط الملفات في `mobile-app/assets/`)
- سياسة الخصوصية (رابط عام) — إلزامي في كلا المتجرين خصوصًا إنك تخزن محادثات المستخدم
- لقطات شاشة ووصف للتطبيق باللغتين العربية والإنجليزية

بعد البناء، ارفع الملفات عبر:
- **Google Play Console** → Production → Create release
- **App Store Connect** → عبر `eas submit` أو Transporter app

## ملاحظات مهمة قبل الإطلاق الفعلي

1. **الأمان**: مفتاح Anthropic API موجود فقط في الـ backend — لا تحطه أبدًا داخل كود التطبيق نفسه.
2. **قاعدة البيانات**: استبدل `users = {}` بقاعدة بيانات حقيقية قبل أي مستخدم فعلي.
3. **المصادقة**: النسخة الحالية تولّد `userId` عشوائي محليًا بدون تسجيل دخول — للإنتاج الفعلي تحتاج نظام حسابات (بريد إلكتروني، أو رقم جوال، أو Google/Apple Sign-In).
4. **التكلفة**: كل رسالة تستهلك رصيد من Anthropic API — راقب الاستخدام وضع حدود لكل مستخدم.
